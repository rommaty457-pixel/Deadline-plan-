-- Deadline Planner tables for Supabase
-- Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.dp_projects (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) <= 80),
  color text not null default '#5268f5',
  created_at timestamptz not null default now()
);

create table if not exists public.dp_tasks (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) <= 120),
  due date not null,
  time text,
  project_id text,
  priority text not null default 'medium' check (priority in ('high','medium','low')),
  status text not null default 'active' check (status in ('active','done')),
  progress integer not null default 0 check (progress between 0 and 100),
  remind_minutes integer not null default 0,
  notes text not null default '',
  updated_at timestamptz not null default now()
);

alter table public.dp_projects enable row level security;
alter table public.dp_tasks enable row level security;

drop policy if exists "Users manage own projects" on public.dp_projects;
create policy "Users manage own projects" on public.dp_projects
for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Users manage own tasks" on public.dp_tasks;
create policy "Users manage own tasks" on public.dp_tasks
for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index if not exists dp_tasks_user_due_idx on public.dp_tasks(user_id, due);
create index if not exists dp_projects_user_idx on public.dp_projects(user_id);
